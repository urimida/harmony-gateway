import React from "react";
import './kind.css';
import FirstSelection from "./kind/FisrtSelection";

function Mainpages() {
  return (
    <div className="Mainpages">
      <FirstSelection></FirstSelection>
    </div>
  );
}

export default Mainpages;
